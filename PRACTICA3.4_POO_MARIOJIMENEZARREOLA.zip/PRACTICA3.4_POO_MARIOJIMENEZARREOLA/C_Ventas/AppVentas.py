#Nombre: MARIO JIMENEZ ARREOLA
#Carrera: Informática
#Materia: Desarrollo de Aplicaciones Web
#Ejercicio o Práctica "practica_3.4_practicando Clases y Objetos"
from claseEmpleado import *
from claseAgenteVentas import *
from claseTripulante import *
from claseGerente import *


jorge = Empleado("duque", 35, "B110", 3000)
print(jorge.nombre)
print(jorge.calcularSueldo(1000,500))

carlos = Tripulante("Dario", 25, "A110", 1000)
print(carlos.mostrarRenovacionLicencia())

helena = Gerente("Helena", 45, "Z210", 200000)
print(helena.calcularSueldo(100,6000))

